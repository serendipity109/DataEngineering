docker run --name my_sql -e MYSQL_ROOT_PASSWORD=MyNewPass -p 3300:3306 -d mysql
